"""
Pipeline:
1. Expects chunked text from chunker.
2. Translate the chunked text from English to Chinese.
3. Edit (fix the grammar and enhance readability) chunks by chunks
4. All the text chunks are concatenated.
5. Input to structurer LLM for structured response
"""
