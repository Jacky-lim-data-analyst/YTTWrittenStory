if __name__ == "__main__":
    import yaml
    sample_input = """"""

    with open('./config/llm_settings.yaml', 'r', encoding='utf-8') as f:
        llm_settings = yaml.safe_load(f)
        print(llm_settings)
